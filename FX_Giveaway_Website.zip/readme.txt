FX Giveaway — Claim Your World
------------------------------------
This website is a sample giveaway-style landing page.

How to publish on Netlify (Free & Simple):
1. Go to https://app.netlify.com/drop
2. Drag and drop the 'index.html' file from this folder.
3. Wait a few seconds — your website will be online instantly!
4. Netlify will give you a public link like: https://yourname.netlify.app

For any customization, you can open 'index.html' in a text editor and adjust text, colors, or links.
